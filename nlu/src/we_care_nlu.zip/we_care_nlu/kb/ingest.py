"""Ingest alignment JSON and WeCare Amharic article KB into knowledge chunks."""

from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path
from typing import Any

from we_care_nlu.contracts.schemas import ChunkRecord
from we_care_nlu.preprocess.normalize import preprocess

_ETH = re.compile(r"[\u1200-\u137F]")


def _hash(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()[:16]


def _subject(text: str) -> str:
    low = text.lower()
    mapping = [
        ("contracept", "family_planning"),
        ("የእርግዝና መከላከያ", "family_planning"),
        ("የወሊድ መቆጣጠሪያ", "family_planning"),
        ("የቤተሰብ ምጣኔ", "family_planning"),
        ("iud", "family_planning"),
        ("አይ.ዩ.ዲ", "family_planning"),
        ("hiv", "hiv"),
        ("ኤች.አይ.ቪ", "hiv"),
        ("ኤችአይቪ", "hiv"),
        ("sti", "sti"),
        ("አባላዘር", "sti"),
        ("ivf", "maternal"),
        ("ፅንስ ማዳቀል", "maternal"),
        ("pregnan", "maternal"),
        ("እርግዝና", "maternal"),
        ("breast", "maternal"),
        ("ጡት", "maternal"),
        ("ከወሊድ", "maternal"),
        ("kegel", "maternal"),
        ("ኬገል", "maternal"),
        ("ultrasound", "maternal"),
        ("አልትራሳውንድ", "maternal"),
        ("pcos", "maternal"),
        ("ፖሊሲስቲክ", "maternal"),
        ("contraindicat", "safety"),
        ("ተቃራኒ", "safety"),
        ("side effect", "safety"),
        ("የጎንዮሽ", "safety"),
    ]
    for needle, cat in mapping:
        if needle in low:
            return cat
    return "general"


def _terms(text: str) -> list[str]:
    terms: list[str] = []
    for token in ("IUCD", "IUD", "HIV", "DMPA", "PMTCT", "VIA", "FP", "IVF", "PCOS", "STI", "Kegel"):
        if token.lower() in text.lower() or token in text:
            terms.append(token)
    return terms


def ingest_alignment(
    payload: dict[str, Any],
    *,
    document_id: str | None = None,
    document_version: str = "unknown",
    default_review_status: str = "unreviewed",
) -> list[ChunkRecord]:
    doc_name = payload.get("document_name") or "unknown.pdf"
    doc_id = document_id or Path(str(doc_name)).stem
    title = payload.get("title") or doc_id
    doc_url = str(payload.get("source_url") or "").strip()
    chunks: list[ChunkRecord] = []
    seen: set[str] = set()
    current_heading = ""
    for row in payload.get("segments") or []:
        kind = row.get("kind") or "paragraph"
        flags = str(row.get("flags") or "")
        is_article = "wecare_article" in flags or "source_amharic" in flags
        en = (row.get("source_text") or row.get("english_text") or "").strip()
        am = (row.get("translated_text") or row.get("amharic_text") or "").strip()
        if is_article:
            # Amharic is primary; tolerate Amharic accidentally placed in source_text.
            if not am and en and _ETH.search(en):
                am, en = en, ""
            elif am and en and _ETH.search(en) and not _ETH.search(am):
                am, en = en, am
        if kind == "heading":
            current_heading = am or en
        if row.get("section"):
            current_heading = str(row["section"])
        if not en and not am:
            continue
        if kind in {"header", "footer", "page_number"}:
            continue
        key = _hash(f"{en}\n{am}")
        if key in seen:
            continue
        seen.add(key)
        status = default_review_status
        if "human_reviewed" in flags:
            status = "reviewed"
        if "source_english" in flags or "source_amharic" in flags or is_article:
            status = "source"
        page = row.get("page_number")
        try:
            page_i = int(page) if page not in (None, "") else None
        except (TypeError, ValueError):
            page_i = None
        text_for_terms = f"{en} {am}"
        if is_article and "translated_guideline" not in flags:
            source_kind = "wecare_article"
        elif "translated_guideline" in flags or (
            "source_amharic" in flags and "wecare_article" not in flags
        ):
            source_kind = "amharic_guideline"
        elif "source_english" in flags:
            source_kind = "english_guideline"
        else:
            source_kind = "phase1_alignment"
        source_url = str(row.get("source_url") or doc_url or "").strip()
        rec = ChunkRecord(
            evidence_id=row.get("segment_id") or f"{doc_id}:{key}",
            document_id=doc_id,
            document_title=title,
            section=current_heading,
            heading=current_heading,
            page=page_i,
            english_text=en,
            amharic_text=am,
            review_status=status,
            medical_subject=_subject(text_for_terms),
            document_version=document_version,
            source_kind=source_kind,
            terms=_terms(text_for_terms),
            content_hash=key,
            source_url=source_url,
        )
        chunks.append(rec)
    return chunks


def ingest_path(path: str | Path, **kwargs) -> list[ChunkRecord]:
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    documents = data.get("documents")
    if isinstance(documents, list) and "segments" not in data:
        chunks: list[ChunkRecord] = []
        for doc in documents:
            if isinstance(doc, dict):
                chunks.extend(ingest_alignment(doc, **kwargs))
        return chunks
    return ingest_alignment(data, **kwargs)


def tokenize(text: str) -> list[str]:
    pre = preprocess(text)
    raw = [
        t
        for t in pre.normalized.lower().replace(".", " ").replace(",", " ").replace("?", " ").replace("!", " ").split()
        if t
    ]
    stripped: list[str] = []
    for tok in raw:
        if any("\u1200" <= ch <= "\u137F" for ch in tok) and len(tok) >= 5 and tok.endswith("ን"):
            stripped.append(tok[:-1])
    raw = raw + stripped
    extra: list[str] = []
    for tok in raw:
        if any("\u1200" <= ch <= "\u137F" for ch in tok) and len(tok) >= 4:
            extra.append(tok[:4])
            if len(tok) >= 5:
                extra.append(tok[:5])
    return raw + extra
