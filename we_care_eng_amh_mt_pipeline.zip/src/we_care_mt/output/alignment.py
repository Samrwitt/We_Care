"""Aligned source/target export as JSON and CSV."""

from __future__ import annotations

import csv
import json
from pathlib import Path

from we_care_mt.schema import DocumentStructure, Segment, to_plain


def write_alignment(
    doc: DocumentStructure,
    segments: list[Segment],
    out_dir: Path,
) -> dict[str, Path]:
    out_dir.mkdir(parents=True, exist_ok=True)
    stem = Path(doc.document_name).stem
    json_path = out_dir / f"{stem}.alignment.json"
    csv_path = out_dir / f"{stem}.alignment.csv"

    payload = {
        "document_name": doc.document_name,
        "source_path": doc.source_path,
        "page_count": doc.page_count,
        "title": doc.title,
        "repeating_headers": doc.repeating_headers,
        "repeating_footers": doc.repeating_footers,
        "complex_layout_pages": doc.complex_layout_pages,
        "empty_or_image_pages": doc.empty_or_image_pages,
        "extraction_warnings": to_plain(doc.warnings),
        "layout_limitations": [
            "Reconstructed reading order is best-effort; InDesign multi-column pages may still mis-order.",
            "Complex / merged tables are flagged uncertain and must be reviewed against the source PDF.",
            "Decorative running headers and page numbers are excluded from translation but retained in extraction JSON.",
            "Output PDFs are structured reconstructions, not pixel-identical copies of the source layout.",
        ],
        "segments": [s.to_alignment_row() for s in segments],
    }
    json_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")

    fieldnames = list(segments[0].to_alignment_row().keys()) if segments else [
        "segment_id",
        "document_name",
        "page_number",
        "block_id",
        "kind",
        "source_text",
        "translated_text",
        "model_id",
        "status",
        "glossary_hits",
        "flags",
        "error",
    ]
    with csv_path.open("w", encoding="utf-8", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=fieldnames)
        writer.writeheader()
        for seg in segments:
            writer.writerow(seg.to_alignment_row())
    return {"json": json_path, "csv": csv_path}
