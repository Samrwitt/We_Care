"""Locate and register Ethiopic-capable fonts for PDF/DOCX output."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class FontBundle:
    amharic_regular: Path
    amharic_bold: Path
    latin_regular: Path
    latin_bold: Path


@dataclass(frozen=True)
class ReportLabNames:
    amharic: str = "WCMT-Amharic"
    amharic_bold: str = "WCMT-Amharic-Bold"
    latin: str = "WCMT-Latin"
    latin_bold: str = "WCMT-Latin-Bold"


def locate_fonts(fonts_dir: Path | None = None) -> FontBundle:
    candidates_amh = [
        "NotoSansEthiopic-Regular.ttf",
        "NotoSerifEthiopic-Regular.ttf",
        "AbyssinicaSIL-Regular.ttf",
    ]
    candidates_amh_bold = [
        "NotoSansEthiopic-Bold.ttf",
        "NotoSerifEthiopic-Bold.ttf",
    ]
    candidates_lat = ["NotoSans-Regular.ttf", "DejaVuSans.ttf", "LiberationSans-Regular.ttf"]
    candidates_lat_bold = ["NotoSans-Bold.ttf", "DejaVuSans-Bold.ttf", "LiberationSans-Bold.ttf"]

    search = []
    if fonts_dir:
        search.append(Path(fonts_dir))
    search.extend(
        [
            Path("/usr/share/fonts/truetype/noto"),
            Path("/usr/share/fonts/truetype/abyssinica"),
            Path("/usr/share/fonts/truetype/dejavu"),
            Path("/usr/share/fonts/truetype/liberation"),
        ]
    )

    def pick(names: list[str]) -> Path:
        for folder in search:
            for name in names:
                path = folder / name
                if path.exists():
                    return path
        raise FileNotFoundError(
            "Could not find required fonts "
            f"{names}. Place Noto Sans Ethiopic in data/fonts/ (see README)."
        )

    amh = pick(candidates_amh)
    try:
        amh_b = pick(candidates_amh_bold)
    except FileNotFoundError:
        amh_b = amh
    lat = pick(candidates_lat)
    try:
        lat_b = pick(candidates_lat_bold)
    except FileNotFoundError:
        lat_b = lat
    return FontBundle(amh, amh_b, lat, lat_b)


_REGISTERED = False
_NAMES = ReportLabNames()


def register_reportlab_fonts(fonts: FontBundle | None = None) -> ReportLabNames:
    global _REGISTERED
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont

    if fonts is None:
        fonts = locate_fonts()
    if not _REGISTERED:
        pdfmetrics.registerFont(TTFont(_NAMES.amharic, str(fonts.amharic_regular)))
        pdfmetrics.registerFont(TTFont(_NAMES.amharic_bold, str(fonts.amharic_bold)))
        pdfmetrics.registerFont(TTFont(_NAMES.latin, str(fonts.latin_regular)))
        pdfmetrics.registerFont(TTFont(_NAMES.latin_bold, str(fonts.latin_bold)))
        _REGISTERED = True
    return _NAMES
