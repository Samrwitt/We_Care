"""Amharic PDF reconstruction. Layout is structured, not pixel-identical to InDesign."""

from __future__ import annotations

from collections import defaultdict
from pathlib import Path

from we_care_mt.output.fonts import FontBundle, register_reportlab_fonts
from we_care_mt.schema import DocumentStructure, Segment


def write_amharic_pdf(
    doc: DocumentStructure,
    segments: list[Segment],
    path: Path,
    fonts: FontBundle | None = None,
    title: str | None = None,
) -> Path:
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
    from reportlab.lib.units import mm
    from reportlab.platypus import (
        PageBreak,
        Paragraph,
        SimpleDocTemplate,
        Spacer,
        Table,
        TableStyle,
    )
    from reportlab.lib import colors

    names = register_reportlab_fonts(fonts)
    styles = getSampleStyleSheet()
    heading = ParagraphStyle(
        "AmhH",
        parent=styles["Heading1"],
        fontName=names.amharic_bold,
        fontSize=13,
        leading=18,
        spaceAfter=6,
        wordWrap="CJK",
    )
    body = ParagraphStyle(
        "AmhB",
        parent=styles["BodyText"],
        fontName=names.amharic,
        fontSize=10.5,
        leading=16,
        spaceAfter=4,
        wordWrap="CJK",
    )
    caption = ParagraphStyle(
        "AmhC",
        parent=styles["BodyText"],
        fontName=names.latin,
        fontSize=8,
        leading=11,
        textColor=colors.HexColor("#444444"),
    )
    by_block: dict[str, list[Segment]] = defaultdict(list)
    for seg in segments:
        by_block[seg.block_id.split("#")[0]].append(seg)

    path.parent.mkdir(parents=True, exist_ok=True)
    pdf = SimpleDocTemplate(
        str(path),
        pagesize=A4,
        leftMargin=18 * mm,
        rightMargin=18 * mm,
        title=title or doc.title,
    )
    story = []
    story.append(Paragraph(_esc(title or doc.title), heading))
    story.append(
        Paragraph(
            _esc(
                "ይህ ሰነድ በማሽን የተተረጎመ ረቂቅ ነው። ክሊኒካዊ አጠቃቀም ከብቁ የሰው ግምገማ በፊት አይፈቀድም። "
                "This is a machine-translated draft. Not for clinical use without qualified human review."
            ),
            caption,
        )
    )
    story.append(Spacer(1, 8))

    current_page = None
    for block in doc.blocks:
        if block.kind in {"header", "footer", "page_number"}:
            continue
        if current_page is not None and block.page != current_page:
            story.append(PageBreak())
        if current_page != block.page:
            story.append(Paragraph(_esc(f"— ምንጭ ገጽ / source page {block.page} —"), caption))
            current_page = block.page

        if block.kind == "table" and block.table is not None:
            story.append(_build_translated_table(block.block_id, segments, names, body))
            if block.table.uncertain:
                story.append(
                    Paragraph(
                        _esc("⚠ Table extraction was uncertain. Review against the source PDF."),
                        caption,
                    )
                )
            continue

        segs = by_block.get(block.block_id, [])
        text = " ".join(s.translated_text for s in segs if s.translated_text).strip()
        if not text:
            continue
        style = heading if block.kind == "heading" else body
        prefix = f"{block.list_marker} " if block.list_marker else ""
        story.append(Paragraph(_esc(prefix + text), style))

    pdf.build(story)
    return path


def _build_translated_table(table_id: str, segments: list[Segment], names, body_style):
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.units import mm
    from reportlab.platypus import Table, TableStyle, Paragraph
    from reportlab.lib import colors
    import re

    cells = [s for s in segments if s.block_id.startswith(table_id) or table_id in s.block_id]
    grid: dict[tuple[int, int], str] = {}
    max_r = max_c = 0
    for s in cells:
        m = re.search(r"#r(\d+)c(\d+)$", s.block_id)
        if not m:
            continue
        r, c = int(m.group(1)), int(m.group(2))
        prev = grid.get((r, c), "")
        piece = s.translated_text or s.source_text
        grid[(r, c)] = (prev + " " + piece).strip() if prev else piece
        max_r, max_c = max(max_r, r), max(max_c, c)
    n_cols = max_c + 1 if grid else 1
    n_rows = max_r + 1 if grid else 1
    usable = A4[0] - 36 * mm

    # Wide InDesign matrices cannot fit A4; flatten rather than crash.
    if not grid or n_cols > 6:
        lines = ["<b>ሠንጠረዥ / Table</b> (flattened: source table is too wide for A4 reconstruction)"]
        if grid:
            for r in range(n_rows):
                parts = [grid.get((r, c), "").strip() for c in range(n_cols)]
                parts = [p for p in parts if p]
                if parts:
                    lines.append(_esc(" | ".join(parts)))
        else:
            lines.append(_esc("(empty table)"))
        return Paragraph("<br/>".join(lines), body_style)

    col_w = usable / n_cols
    data = []
    for r in range(n_rows):
        row = []
        for c in range(n_cols):
            row.append(Paragraph(_esc(grid.get((r, c), "")), body_style))
        data.append(row)
    tbl = Table(data, colWidths=[col_w] * n_cols, repeatRows=1)
    tbl.setStyle(
        TableStyle(
            [
                ("FONTNAME", (0, 0), (-1, -1), names.amharic),
                ("FONTSIZE", (0, 0), (-1, -1), 8),
                ("GRID", (0, 0), (-1, -1), 0.4, colors.grey),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
                ("LEFTPADDING", (0, 0), (-1, -1), 2),
                ("RIGHTPADDING", (0, 0), (-1, -1), 2),
                ("TOPPADDING", (0, 0), (-1, -1), 2),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 2),
            ]
        )
    )
    return tbl


def _esc(text: str) -> str:
    return (
        (text or "")
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace("\n", "<br/>")
    )
