"""Side-by-side English / Amharic review PDF."""

from __future__ import annotations

from pathlib import Path

from we_care_mt.output.fonts import FontBundle, register_reportlab_fonts
from we_care_mt.output.pdf_writer import _esc
from we_care_mt.schema import DocumentStructure, Segment


def write_bilingual_pdf(
    doc: DocumentStructure,
    segments: list[Segment],
    path: Path,
    fonts: FontBundle | None = None,
) -> Path:
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
    from reportlab.lib.units import mm
    from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

    names = register_reportlab_fonts(fonts)
    styles = getSampleStyleSheet()
    en_style = ParagraphStyle("BiEn", parent=styles["BodyText"], fontName=names.latin, fontSize=8.5, leading=12)
    am_style = ParagraphStyle(
        "BiAm", parent=styles["BodyText"], fontName=names.amharic, fontSize=9, leading=13, wordWrap="CJK"
    )
    head = ParagraphStyle("BiH", parent=styles["Heading1"], fontName=names.latin_bold, fontSize=12, leading=16)

    path.parent.mkdir(parents=True, exist_ok=True)
    pdf = SimpleDocTemplate(str(path), pagesize=A4, leftMargin=12 * mm, rightMargin=12 * mm)
    story = [
        Paragraph(_esc(f"Bilingual review: {doc.title}"), head),
        Paragraph(
            "Machine translation draft. Not clinically validated. Reviewers must compare every "
            "segment with the source PDF. Page numbers refer to the English original.",
            en_style,
        ),
        Spacer(1, 8),
    ]
    data = [
        [
            Paragraph("<b>Page</b>", en_style),
            Paragraph("<b>English source</b>", en_style),
            Paragraph("<b>Amharic (draft)</b>", en_style),
        ]
    ]
    for seg in segments:
        if seg.kind in {"header", "footer", "page_number"}:
            continue
        if not seg.source_text.strip():
            continue
        flag = " ⚠" if seg.flags else ""
        data.append(
            [
                Paragraph(str(seg.page_number), en_style),
                Paragraph(_esc(seg.source_text) + (f"<br/><font size='7' color='#aa0000'>{flag}</font>" if flag else ""), en_style),
                Paragraph(_esc(seg.translated_text or "—"), am_style),
            ]
        )
    col_w = [18 * mm, 80 * mm, 80 * mm]
    tbl = Table(data, colWidths=col_w, repeatRows=1)
    tbl.setStyle(
        TableStyle(
            [
                ("GRID", (0, 0), (-1, -1), 0.3, colors.HexColor("#cccccc")),
                ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#eef2f7")),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
                ("LEFTPADDING", (0, 0), (-1, -1), 4),
                ("RIGHTPADDING", (0, 0), (-1, -1), 4),
                ("TOPPADDING", (0, 0), (-1, -1), 3),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
            ]
        )
    )
    story.append(tbl)
    pdf.build(story)
    return path
