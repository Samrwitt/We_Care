"""Editable bilingual DOCX with Ethiopic-capable fonts."""

from __future__ import annotations

from pathlib import Path

from we_care_mt.output.fonts import FontBundle, locate_fonts
from we_care_mt.schema import DocumentStructure, Segment


def write_docx(
    doc: DocumentStructure,
    segments: list[Segment],
    path: Path,
    fonts: FontBundle | None = None,
) -> Path:
    from docx import Document
    from docx.oxml.ns import qn
    from docx.shared import Pt, RGBColor

    fonts = fonts or locate_fonts()
    document = Document()
    styles = document.styles
    normal = styles["Normal"]
    normal.font.name = "Noto Sans Ethiopic"
    normal.font.size = Pt(11)
    rpr = normal.element.get_or_add_rPr()
    rfonts = rpr.get_or_add_rFonts()
    rfonts.set(qn("w:eastAsia"), "Noto Sans Ethiopic")
    rfonts.set(qn("w:ascii"), "Noto Sans")
    rfonts.set(qn("w:hAnsi"), "Noto Sans")

    title = document.add_heading(doc.title, level=0)
    for run in title.runs:
        run.font.color.rgb = RGBColor(0x1F, 0x3A, 0x5F)

    note = document.add_paragraph(
        "Machine-translated draft. Not for clinical use without qualified human review. "
        "ይህ በማሽን የተተረጎመ ረቂቅ ነው።"
    )
    note.runs[0].italic = True

    current_page = None
    for seg in segments:
        if seg.kind in {"header", "footer", "page_number"}:
            continue
        if not (seg.source_text or "").strip():
            continue
        if current_page != seg.page_number:
            current_page = seg.page_number
            p = document.add_paragraph(f"Source page {seg.page_number}")
            p.runs[0].font.size = Pt(9)
            p.runs[0].font.color.rgb = RGBColor(0x66, 0x66, 0x66)

        if seg.kind == "heading":
            document.add_heading(seg.translated_text or seg.source_text, level=2)
            document.add_paragraph(f"EN: {seg.source_text}")
            continue

        p = document.add_paragraph()
        run_am = p.add_run(seg.translated_text or "—")
        run_am.font.name = "Noto Sans Ethiopic"
        run_am._element.rPr.rFonts.set(qn("w:eastAsia"), "Noto Sans Ethiopic")
        p2 = document.add_paragraph(f"EN: {seg.source_text}")
        p2.runs[0].font.size = Pt(9)
        p2.runs[0].font.color.rgb = RGBColor(0x44, 0x44, 0x44)

    path.parent.mkdir(parents=True, exist_ok=True)
    document.save(str(path))
    return path
